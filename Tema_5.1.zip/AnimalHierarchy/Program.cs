﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animalhierarchy
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = new Cat(1, "Luna", "Male");
            var b = new Cat(3, "Miti", "Male");
            var c = new Cat(4, "Re", "Male");
            var d = new Cat(7, "Ma", "Male");
            var e = new Cat(9, "Nent", "Male");




         




        }
    }


//    Create a hierarchy Dog, Frog, Cat, Kitten, Tomcat and define useful constructors and methods.Dogs, frogs and cats are Animals.
//All animals can produce sound (specified by the ISound interface). Kittens and tomcats are cats.All animals are described by age, name and sex.
//Kittens can be only female and tomcats can be only male. Each animal produces a specific sound.
//Create arrays of different kinds of animals and calculate the average age of each kind of animal using a static method(you may use LINQ).
    public class Animals
    {
        public Animals(int Age, string Name, string Sex)
        {
            

        }

        public int Age { get; set; }
        public string Name { get; set; }

        public string Sex { get; set; }
    }
    public class Dog : Animals
    {
        public Dog(int Age, string Name, string Sex)
            : base(Age, Name, Sex)
        {

        }

        

    }
    public class Frog : Animals
    {
        public Frog(int Age, string Name, string Sex)
           : base(Age, Name, Sex)
        {

        }
    }
    public class Cat : Animals
    {
        public Cat(int Age, string Name, string Sex)
           : base(Age, Name, Sex)
        {

        }

    }
    public interface ISound
    {

        string Sound { get; set; }
        public class SoundManager
        {
            List<ISound> sounds;

            public SoundManager()
            {
                sounds = new List<ISound>();
            }

            public void Add(ISound s)
            {
                sounds.Add(s);
            }
        }

     

    }
    public class Kitten : Cat
    {
        public Kitten(int Age, string Name, string Sex)
           : base(Age, Name, Sex)
        {

        }

        //Kittens can be only female and tomcats can be only male.

        public string Sextype()
        {

            {
                if (Sex == "Male")
                {
                    return "Male";
                }

                return "Kitten can be only male";
            }
        }
    }
    public class Tomcat : Cat
    {

        public Tomcat(int Age, string Name, string Sex)
           : base(Age, Name, Sex)
        {

        }
        public string Sextype()
        {

            {
                if (Sex == "Female")
                {
                    return "Female";
                }

                return "Kitten can be only Female";
            }
        }

    }
    




}
