﻿namespace OOP2.Human.Worker.Students
{
    public class SuperStudent : Student
    {
        public SuperStudent(string firstName, string lastName)
            : base(firstName, lastName)
        {

        }
    }
}
