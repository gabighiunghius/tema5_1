﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2.Human.Worker.Students
{
    class Program
    {
        static void Main(string[] args)
        {

            //            Define abstract class Human with a first name and a last name. 

            //Define a new class Student which is derived from Human and has a new field – grade. 

            //Define class Worker derived from Human with a new property WeekSalary and WorkHoursPerDay and a method MoneyPerHour() that returns money 

            //earned per hour by the worker. Define the proper constructors and properties for this hierarchy.



            //Tasks:

            //Initialize a list of 10 students and sort them by grade in ascending order (use LINQ or OrderBy() extension method).

            //Initialize a list of 10 workers and sort them by money per hour in descending order.

            //Merge the lists and sort them by first name and last name.




            var a = new Student("Andrei", "Sca");
            var b = new Student("Mihai", "Scc");
            var c = new Student("Cosmin", "Scf");
            var d = new Student("Ilie", "Scr");
            var e = new Student("Catalin", "Scq");





            var student = new StudentManager();

            student.Add(a);
            student.Add(b);
            student.Add(c);
            student.Add(d);
            student.Add(e);

        }

        //IEnumerable<StudentManager> query = Student.OrderBy(firstName => firstName);

   
    public class StudentManager
        {
            private List<Student> studentList;

            public StudentManager()
            {
                studentList = new List<Student>();
            }

            public void Add(Student p)
            {
                studentList.Add(p);
            }
        }
    }
    }

